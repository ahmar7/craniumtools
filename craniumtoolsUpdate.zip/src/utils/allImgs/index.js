import Logo from "../../assets/img/Logo.png";
import Delete from "../../assets/img/delete.svg";
import Img from "../../assets/img/img.png";
import Dp from "../../assets/img/circle.png";
import Twittersmall from "../../assets/img/twitter.svg";
import Discordsmall from "../../assets/img/discord.svg";
import Cross from "../../assets/img/cross.png";
import Plus from "../../assets/img/plus 1.svg";
import Vector from "../../assets/img/Vector.svg";
import Layoutbg from "../../assets/img/layoutbg.png";
import Edit from "../../assets/img/edit.svg";
import HeaderImg from "../../assets/img/Header Image.png";
import Icon1 from "../../assets/img/eIcons/PBaaS.svg";
import Icon2 from "../../assets/img/eIcons/VerusID.svg";
import Icon3 from "../../assets/img/eIcons/DeFI.svg";
import Icon4 from "../../assets/img/eIcons/Data.svg";
import Discord from "../../assets/img/socialicons/Discord.svg";
import Twitter from "../../assets/img/socialicons/Telegram.svg";
import ChartIcon1 from "../../assets/img/dashboardIcons/icon.svg";
import ChartIcon4 from "../../assets/img/dashboardIcons/icon (3).svg";
import ChartIcon2 from "../../assets/img/dashboardIcons/icon (1).svg";
import ChartIcon3 from "../../assets/img/dashboardIcons/icon (2).svg";
import Metamask from "../../assets/img/walletIcons/metamask.svg";
import Coinbase from "../../assets/img/walletIcons/coinbase.svg";
import Walletconnect from "../../assets/img/walletIcons/walletconnect.svg";
import Fortmatic from "../../assets/img/walletIcons/fortmatic.svg";

///////////////////////////////////////////////////// Collection Images
export {
  Logo,
  HeaderImg,
  Icon1,
  Icon2,
  Icon3,
  Icon4,
  Discord,
  Twitter,
  Delete,
  ChartIcon1,
  ChartIcon2,
  ChartIcon3,
  ChartIcon4,
  Edit,
  Vector,
  Plus,
  Img,
  Cross,
  Metamask,
  Coinbase,
  Walletconnect,
  Fortmatic,
  Layoutbg,
  Dp,
  Twittersmall,
  Discordsmall,
};
